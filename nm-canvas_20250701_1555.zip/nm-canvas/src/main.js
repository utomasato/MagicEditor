let balls = [];

function Start()
{
    // タイトルの設定
    SetTitle("nm-canvas");

    // 初期ボール生成
    GenerateBalls();

    SetMouseCursor('pointer');       // つかめる
}

function Update()
{
    if (CheckKeyDown(Key.C)) {
        balls = [];
    }
    if (CheckKeyDown(Key.R)) {
        GenerateBalls();
    }
    if (CheckKeyDown(Key.F)) {
        ToggleFullScreen();
    }
    
    if (CheckKeyDown(Key.S)) {
        CaptureScreenImage("screen");
    }

    if (CheckMouse()) {
        balls.push(new Ball(GetMousePos()));
        PlaySound("item.mp3");
    }

    balls.forEach(ball => {
        ball.Update();
    });
}

function Draw()
{
    let [width, height] = GetScreenSize();

    // 背景のグラデーション
    //Clear(color(25, 25, 112));
    FillRectGradientV(0, 0, width, height, color(135, 206, 235), color(25, 25, 112));

    // ボールの描画
    balls.forEach(ball => {
        ball.Draw();
    });
    
    // 中央に十字線
    DrawLine(width / 2, 0, width / 2, height, color(255, 255, 255, 100), 1);
    DrawLine(0, height / 2, width, height / 2, color(255, 255, 255, 100), 1);
    
    DrawText(100, "CENTER\nTEXT\nDRAWING!!", width / 2, height / 2, color(255, 255, 255, 128), CENTER);

    DrawSunflower(GetMouseX(), GetMouseY(), 100, -CurrentTime());
    DrawEmoji(48, "⏰️", GetMouseX(), GetMouseY(), -CurrentTime());
    
    // FPS表示
    DrawText(12, "FPS: " + GetFPSText(), width - 10, height - 10, color(255, 255, 255), RIGHT);
}

function DrawSunflower(cx, cy, size, angle)
{
    PushTransform();
    Translate(cx, cy);
    
    // 中心部（種の部分）
    FillCircle(0, 0, size * 0.1, color(101, 67, 33));

    // 各花びらを描画
    let petalCount = 8; // 花びらの数
    for (let i = 0; i < petalCount; i++) {
        PushTransform();
        Rotate((TWO_PI / petalCount) * i + angle);
        Translate(size * 0.3, 0);
        FillLensShape(0, 0, size * 0.4, size * 0.2, color(255, 215, 0, 200));
        DrawLensShape(0, 0, size * 0.4, size * 0.2, color(100, 80, 0, 200), 0.5);
        PopTransform();
    }
    
    PopTransform();
}

function GenerateBalls()
{
    let [width, height] = GetScreenSize();

    balls = [];
    // ウィンドウサイズに応じてボール数を調整
    let ballCount = Math.floor((width * height) / 50000);
    ballCount = constrain(ballCount, 5, 50);
    
    for (let i = 0; i < ballCount; i++) {
        balls.push(new Ball(
            { x:random(30, width - 30),
              y:random(30, height - 30) }
        ));
    }
}

function OnResize()
{
    let [width, height] = GetScreenSize();

    // ボールの位置を新しいキャンバスサイズに調整
    balls.forEach(ball => {
        // ボールが画面外に出た場合は画面内に戻す
        ball.x = constrain(ball.x, ball.radius, width - ball.radius);
        ball.y = constrain(ball.y, ball.radius, height - ball.radius);
    });
}

