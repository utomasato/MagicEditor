// ボール用のクラス
class Ball {
    constructor(pos) {
        this.x = pos.x;
        this.y = pos.y;
        this.vx = random(-120, 120);
        this.vy = random(-120, 120);
        this.radius = random(10, 30);
        this.color = color(random(255), random(255), random(255), random(150) + 105);
    }

    Update() {
        let deltaTime = DeltaTime();

        this.x += this.vx * deltaTime;
        this.y += this.vy * deltaTime;

        // 壁で跳ね返る
        if (this.x < this.radius || this.x > width - this.radius) {
            this.vx *= -1;
        }
        if (this.y < this.radius || this.y > height - this.radius) {
            this.vy *= -1;
        }

        // 境界内に収める
        this.x = constrain(this.x, this.radius, width - this.radius);
        this.y = constrain(this.y, this.radius, height - this.radius);
    }

    Draw() {
        FillCircle(this.x, this.y, this.radius, this.color);
        DrawCircle(this.x, this.y, this.radius, color(0, 0, 0, 255), 2);
    }
}

